//
//  AppDelegate.h
//  CropFunctionalityDemo
//
//  Created by tudip on 30/04/15.
//  Copyright (c) 2015 MM-10. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end


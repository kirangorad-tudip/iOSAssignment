//
//  AppDelegate.h
//  IOSAssignments
//
//  Created by tudip on 23/04/15.
//  Copyright (c) 2015 MM-10. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

